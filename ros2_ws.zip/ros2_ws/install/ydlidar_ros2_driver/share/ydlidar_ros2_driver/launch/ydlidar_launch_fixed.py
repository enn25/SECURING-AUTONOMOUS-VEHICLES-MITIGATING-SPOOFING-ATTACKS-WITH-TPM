#!/usr/bin/python3

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import LifecycleNode
from launch_ros.actions import Node
import os

def generate_launch_description():
    # Get the path to the parameter file
    yaml_file_path = os.path.join(
        os.path.expanduser('~'),
        'ros2_ws/src/ydlidar_ros2_driver/params/ydlidar_x2.yaml'
    )
    
    driver_node = LifecycleNode(
        package='ydlidar_ros2_driver',
        executable='ydlidar_ros2_driver_node',
        name='ydlidar_ros2_driver_node',
        namespace='/',
        output='screen',
        emulate_tty=True,
        parameters=[yaml_file_path],
    )

    tf2_node = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='static_tf_pub_laser',
        arguments=['0', '0', '0.02', '0', '0', '0', '1', 'base_link', 'laser_frame'],
    )

    return LaunchDescription([
        driver_node,
        tf2_node,
    ])
