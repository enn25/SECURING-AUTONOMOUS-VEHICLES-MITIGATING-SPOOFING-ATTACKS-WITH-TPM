#!/usr/bin/python3
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import LifecycleNode
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
import os

def generate_launch_description():
    share_dir = get_package_share_directory('ydlidar_ros2_driver')
    rviz_config_file = os.path.join(share_dir, 'config','ydlidar.rviz')
    parameter_file = LaunchConfiguration('params_file')

    params_declare = DeclareLaunchArgument('params_file',
                                           default_value=os.path.join(
                                               share_dir, 'params', 'ydlidar.yaml'),
                                           description='Path to the ROS2 parameters file to use.')

    # LiDAR driver node
    driver_node = LifecycleNode(
        package='ydlidar_ros2_driver',
        executable='ydlidar_ros2_driver_node',
        name='ydlidar_ros2_driver_node',
        namespace='/',
        output='screen',
        emulate_tty=True,
        parameters=[parameter_file],
    )
    
    # Static transforms
    base_footprint_to_base_link = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='static_tf_pub_base',
        arguments=['0', '0', '0.1', '0', '0', '0', '1', 'base_footprint', 'base_link'],
    )
    
    base_link_to_laser = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='static_tf_pub_laser',
        arguments=['0', '0', '0.02','0', '0', '0', '1','base_link','laser_frame'],
    )

    # SLAM node with more detailed configuration
    slam_node = Node(
        package='slam_toolbox',
        executable='async_slam_toolbox_node',
        name='slam_toolbox',
        output='screen',
        parameters=[{
            'use_sim_time': False,
            'autostart': True,
            'map_update_interval': 1.0,  # Update more frequently
            'resolution': 0.05,
            'map_frame': 'map',
            'odom_frame': 'odom',
            'base_frame': 'base_footprint',
            'scan_topic': '/scan',
            'mode': 'mapping',  # Explicitly set mapping mode
            'map_file_name': '',  # Empty for new map
            'map_start_pose': [0.0, 0.0, 0.0],  # x, y, theta
            'map_start_at_dock': True,
            'debug_logging': True,  # Enable debug logging
            'throttle_scans': 1,
            'transform_publish_period': 0.05,  # Publish transforms more frequently
            'tf_buffer_duration': 30.0,
            'minimum_time_interval': 0.5
        }]
    )
    
    # RViz node
    rviz2_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        arguments=['-d', rviz_config_file],
    )
    
    return LaunchDescription([
        params_declare,
        driver_node,
        base_footprint_to_base_link,
        base_link_to_laser,
        slam_node,
        rviz2_node,
    ])
